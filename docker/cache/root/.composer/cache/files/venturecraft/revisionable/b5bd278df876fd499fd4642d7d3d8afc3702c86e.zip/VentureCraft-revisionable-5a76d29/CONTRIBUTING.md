# Contribution Guidelines

Contributions are encouraged and welcome; to keep things organised, all bugs and requests should be
opened in the GitHub "Issues" tab for the main project, at [venturecraft/revisionable/issues](https://github.com/venturecraft/revisionable/issues)

Keep in mind, we are currently maintaining backward-compatibility with Laravel 4.x - please make sure youa

Please submit all pull requests to the [revisionable/develop](https://github.com/VentureCraft/revisionable/tree/develop) branch, so they can be tested before being merged into the master branch.
