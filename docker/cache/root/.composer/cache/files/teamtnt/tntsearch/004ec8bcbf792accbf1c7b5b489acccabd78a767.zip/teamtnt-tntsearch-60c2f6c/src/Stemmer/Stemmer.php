<?php namespace TeamTNT\TNTSearch\Stemmer;

interface Stemmer
{
    public static function stem($word);
}
