<?php declare(strict_types = 1);

namespace PHPStan\Command;

class InceptionNotSuccessfulException extends \Exception
{

}
