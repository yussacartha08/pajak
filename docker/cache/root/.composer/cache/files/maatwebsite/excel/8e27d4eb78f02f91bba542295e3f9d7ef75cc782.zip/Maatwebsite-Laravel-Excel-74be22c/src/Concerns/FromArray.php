<?php

namespace Maatwebsite\Excel\Concerns;

interface FromArray
{
    /**
     * @return array
     */
    public function array(): array;
}
