<?php declare(strict_types = 1);

namespace PHPStan\Reflection;

interface FinalizableReflection
{

	public function isFinal(): bool;

}
