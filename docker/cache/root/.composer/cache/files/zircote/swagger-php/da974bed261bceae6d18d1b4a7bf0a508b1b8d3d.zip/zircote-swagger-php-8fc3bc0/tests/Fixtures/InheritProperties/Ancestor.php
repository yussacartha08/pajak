<?php declare(strict_types=1);

namespace OpenApiFixtures;

/**
 * An intermediate class
 */
class Ancestor extends GrandAncestor
{

    /**
     * Without annotations
     */
    public $firstname;
}
