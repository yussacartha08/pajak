- Larastan Version: #.#.#
- `--level` used:

### Description:

### Laravel code where the issue was found:
