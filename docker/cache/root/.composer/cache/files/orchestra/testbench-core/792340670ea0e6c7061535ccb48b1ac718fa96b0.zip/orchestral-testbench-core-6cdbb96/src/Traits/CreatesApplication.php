<?php

namespace Orchestra\Testbench\Traits;

use Orchestra\Testbench\Concerns\CreatesApplication as Concern;

/**
 * @deprecated v3.6.0
 * @see \Orchestra\Testbench\Concerns\CreatesApplication
 */
trait CreatesApplication
{
    use Concern;
}
