<?php declare(strict_types = 1);

namespace PHPStan\Reflection;

/**
 * @deprecated
 */
interface BrokerAwareClassReflectionExtension extends BrokerAwareExtension
{

}
