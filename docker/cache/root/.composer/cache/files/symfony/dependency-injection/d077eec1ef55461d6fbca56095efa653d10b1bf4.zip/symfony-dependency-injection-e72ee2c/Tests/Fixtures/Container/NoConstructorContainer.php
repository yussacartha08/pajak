<?php

namespace Symfony\Component\DependencyInjection\Tests\Fixtures\Container;

use Symfony\Component\DependencyInjection\Container;

class NoConstructorContainer extends Container
{
}
