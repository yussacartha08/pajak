<?php

namespace TeamTNT\TNTSearch\Exceptions;

use Exception;

class IndexNotFoundException extends Exception
{
}
