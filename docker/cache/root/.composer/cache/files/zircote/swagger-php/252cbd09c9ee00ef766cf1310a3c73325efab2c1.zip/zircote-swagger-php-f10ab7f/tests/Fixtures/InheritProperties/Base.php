<?php

namespace OpenApiFixtures;

/**
 * @OA\Schema()
 */
class Base
{

    /**
     * @OA\Property();
     * @var string
     */
    public $baseProperty;
}
