<?php declare(strict_types=1);

namespace OpenApiFixtures;

class AncestorWithoutDocBlocks extends GrandAncestor
{
    public $firstname;
}
