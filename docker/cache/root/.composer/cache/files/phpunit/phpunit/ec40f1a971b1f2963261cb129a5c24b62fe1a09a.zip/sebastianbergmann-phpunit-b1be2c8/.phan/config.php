<?php declare(strict_types=1);
return [
    'directory_list'                  => [ 'src/', 'vendor/' ],
    'exclude_analysis_directory_list' => [ 'vendor/', 'src/Framework/Assert/' ],

    'target_php_version'              => '7.1',
];
