<?php

namespace GrumPHP\Exception;

interface ExceptionInterface
{
}
