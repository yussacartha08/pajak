# Backers

Development of PHPStan is made possible thanks to these awesome backers!
You can become one of them by [pledging on Patreon](https://www.patreon.com/phpstan).

Check out all the tiers - higher ones include additional goodies like placing
the logo of your company in PHPStan's README.

# $50+

* MessageBird

# $10+

* Adam Lundrigan
* Scott Arciszewski

# $5+

* Adam Žurek
* Bart Reunes
* Carlos C Soto
* Craig Mayhew
* David Šolc
* Dennis Haarbrink
* Haralan Dobrev
* Ilija Tovilo
* Jake B
* Jakub Chábek
* Jakub Červený
* Jan Endel
* Jan Kuchař
* Lars Roettig
* Lukas Unger
* Masaru Yamagishi
* Michael Moll
* Pavel Vondrášek
* René Kliment
* Rudolph Gottesheim
* seagoj
* Stefan Zielke
* Thomas Daugaard
* Tomasz
* Tommy Muehle
* Vašek Brychta
* Woda Digital

# $1+

* Andrew Barlow
* Broken Bialek
* Christian Sjöström
* Craig Duncan
* Honza Cerny
* Ian Den Hartog
* Ivan Kvasnica
* korchasa
* Lucas Dos Santos Abreu
* Martin Lukeš
* Matej Drame
* Michal Mleczko
* Michał Włodarczyk
* Oliver Klee
* Ondrej Vodacek
* Wouter Admiraal
