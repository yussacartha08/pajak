<?php
/*
 * This file is part of PHPUnit.
 *
 * (c) Sebastian Bergmann <sebastian@phpunit.de>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */
trait AbstractTrait
{
    abstract public function doSomething();

    public function mockableMethod()
    {
        return true;
    }

    public function anotherMockableMethod()
    {
        return true;
    }
}
