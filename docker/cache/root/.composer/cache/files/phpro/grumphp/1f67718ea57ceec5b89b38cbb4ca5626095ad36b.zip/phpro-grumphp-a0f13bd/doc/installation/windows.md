# Windows Pre-Install
So you are running windows but still want to unleash the power of GrumPHP? No problem: everything is possible!
You will have to make sure that following items are available on the command line:

- php
- composer
- git
